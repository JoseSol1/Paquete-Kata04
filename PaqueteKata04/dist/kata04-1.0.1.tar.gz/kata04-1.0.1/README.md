##Installation

Intsalar utilizando pip install

##Usage

Llamar a la clase ConverterService, y a la funcion convertMatrix()

Ejemplo:

from ConverterService umport convertMatrix

matrix = [Matriz aqui]
convertedMatrix= convertMatrix(matrix)